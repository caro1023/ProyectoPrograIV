﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto
{
    public class Persona
    {
        public string cedula { get; set; }
        public string nombre { get; set; }
        public string apellido1 { get; set; }
        public string apellido2 { get; set; }
        public string fechaNac { get; set; }
        public string usuario { get; set; }
        public string clave { get; set; }
        public string correo { get; set; }
        public int telefono { get; set; }
    }
}
