﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Plataforma
{
    public partial class FrMenu : Form
    {
        public FrMenu()
        {
            InitializeComponent();
        }

        private void BtnAdministracion_CheckedChanged(object sender, EventArgs e)
        {
            TabMenu.SelectedIndex = 0;
        }

        private void BtnConsultas_CheckedChanged(object sender, EventArgs e)
        {
            TabMenu.SelectedIndex = 1;
        }

        private void BtnMantenimiento_CheckedChanged(object sender, EventArgs e)
        {
            TabMenu.SelectedIndex = 2;
        }

        private void BtnLaboratorio_CheckedChanged(object sender, EventArgs e)
        {
            TabMenu.SelectedIndex = 3;
        }

        private void BtnCerrar_CheckedChanged(object sender, EventArgs e)
        {
            FrMenu Plantilla = new FrMenu();
            this.Hide();
            Plantilla.Close();
        }

        private void pictureBox2_MouseClick(object sender, MouseEventArgs e)
        {
            Cronograma Plantilla = new Cronograma();
            //this.Hide();
            Plantilla.Show();
        }
    }
}
