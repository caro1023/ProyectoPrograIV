﻿namespace Plataforma
{
    partial class FrMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TabMenu = new System.Windows.Forms.TabControl();
            this.TabAdministracion = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.TabConsultas = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.TabMantenimiento = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.TabLaboratorio = new System.Windows.Forms.TabPage();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button5 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BtnCerrar = new System.Windows.Forms.RadioButton();
            this.BtnLaboratorio = new System.Windows.Forms.RadioButton();
            this.BtnAdministracion = new System.Windows.Forms.RadioButton();
            this.BtnMantenimiento = new System.Windows.Forms.RadioButton();
            this.BtnConsultas = new System.Windows.Forms.RadioButton();
            this.TabMenu.SuspendLayout();
            this.TabAdministracion.SuspendLayout();
            this.TabConsultas.SuspendLayout();
            this.TabMantenimiento.SuspendLayout();
            this.TabLaboratorio.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabMenu
            // 
            this.TabMenu.Controls.Add(this.TabAdministracion);
            this.TabMenu.Controls.Add(this.TabConsultas);
            this.TabMenu.Controls.Add(this.TabMantenimiento);
            this.TabMenu.Controls.Add(this.TabLaboratorio);
            this.TabMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabMenu.Location = new System.Drawing.Point(0, 0);
            this.TabMenu.Name = "TabMenu";
            this.TabMenu.SelectedIndex = 0;
            this.TabMenu.Size = new System.Drawing.Size(1149, 449);
            this.TabMenu.TabIndex = 4;
            // 
            // TabAdministracion
            // 
            this.TabAdministracion.Controls.Add(this.button4);
            this.TabAdministracion.Location = new System.Drawing.Point(4, 22);
            this.TabAdministracion.Name = "TabAdministracion";
            this.TabAdministracion.Padding = new System.Windows.Forms.Padding(3);
            this.TabAdministracion.Size = new System.Drawing.Size(1141, 423);
            this.TabAdministracion.TabIndex = 0;
            this.TabAdministracion.Text = "Administrador";
            this.TabAdministracion.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(205, 200);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 1;
            this.button4.Text = "Administador";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // TabConsultas
            // 
            this.TabConsultas.Controls.Add(this.button1);
            this.TabConsultas.Location = new System.Drawing.Point(4, 22);
            this.TabConsultas.Name = "TabConsultas";
            this.TabConsultas.Padding = new System.Windows.Forms.Padding(3);
            this.TabConsultas.Size = new System.Drawing.Size(485, 423);
            this.TabConsultas.TabIndex = 1;
            this.TabConsultas.Text = "Consultas";
            this.TabConsultas.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(191, 227);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Consultas";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // TabMantenimiento
            // 
            this.TabMantenimiento.Controls.Add(this.button2);
            this.TabMantenimiento.Location = new System.Drawing.Point(4, 22);
            this.TabMantenimiento.Name = "TabMantenimiento";
            this.TabMantenimiento.Padding = new System.Windows.Forms.Padding(3);
            this.TabMantenimiento.Size = new System.Drawing.Size(485, 423);
            this.TabMantenimiento.TabIndex = 2;
            this.TabMantenimiento.Text = "Mantenimiento";
            this.TabMantenimiento.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(205, 200);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(95, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Mantenimiento";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // TabLaboratorio
            // 
            this.TabLaboratorio.Controls.Add(this.pictureBox7);
            this.TabLaboratorio.Controls.Add(this.pictureBox6);
            this.TabLaboratorio.Controls.Add(this.pictureBox5);
            this.TabLaboratorio.Controls.Add(this.pictureBox4);
            this.TabLaboratorio.Controls.Add(this.pictureBox3);
            this.TabLaboratorio.Controls.Add(this.pictureBox2);
            this.TabLaboratorio.Controls.Add(this.pictureBox1);
            this.TabLaboratorio.Controls.Add(this.label2);
            this.TabLaboratorio.Controls.Add(this.label1);
            this.TabLaboratorio.Controls.Add(this.comboBox2);
            this.TabLaboratorio.Controls.Add(this.button5);
            this.TabLaboratorio.Controls.Add(this.comboBox1);
            this.TabLaboratorio.Controls.Add(this.button3);
            this.TabLaboratorio.Location = new System.Drawing.Point(4, 22);
            this.TabLaboratorio.Name = "TabLaboratorio";
            this.TabLaboratorio.Padding = new System.Windows.Forms.Padding(3);
            this.TabLaboratorio.Size = new System.Drawing.Size(485, 423);
            this.TabLaboratorio.TabIndex = 3;
            this.TabLaboratorio.Text = "Laboratorio";
            this.TabLaboratorio.UseVisualStyleBackColor = true;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Plataforma.Properties.Resources.img21;
            this.pictureBox7.Location = new System.Drawing.Point(308, 214);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(119, 131);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 13;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Plataforma.Properties.Resources.img21;
            this.pictureBox6.Location = new System.Drawing.Point(169, 214);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(119, 131);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 12;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Plataforma.Properties.Resources.img21;
            this.pictureBox5.Location = new System.Drawing.Point(28, 214);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(119, 131);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 11;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Plataforma.Properties.Resources.img2;
            this.pictureBox4.Location = new System.Drawing.Point(308, 77);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(119, 131);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 10;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Plataforma.Properties.Resources.img2;
            this.pictureBox3.Location = new System.Drawing.Point(169, 77);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(119, 131);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Plataforma.Properties.Resources.img2;
            this.pictureBox2.Location = new System.Drawing.Point(28, 77);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(119, 131);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.DarkGray;
            this.pictureBox1.Location = new System.Drawing.Point(12, 67);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(446, 288);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(208, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Piso";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Edifico";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Piso 1",
            "Piso 2",
            "Piso 3",
            "Piso 4",
            "Piso 5"});
            this.comboBox2.Location = new System.Drawing.Point(257, 21);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 4;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(384, 20);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 3;
            this.button5.Text = "Consultar";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Edificio 1",
            "Edificio 2",
            "Edificio 3"});
            this.comboBox1.Location = new System.Drawing.Point(78, 22);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 2;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(384, 377);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 1;
            this.button3.Text = "Laboratorio";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel1.Controls.Add(this.BtnCerrar);
            this.panel1.Controls.Add(this.BtnLaboratorio);
            this.panel1.Controls.Add(this.BtnAdministracion);
            this.panel1.Controls.Add(this.BtnMantenimiento);
            this.panel1.Controls.Add(this.BtnConsultas);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1149, 26);
            this.panel1.TabIndex = 5;
            // 
            // BtnCerrar
            // 
            this.BtnCerrar.Appearance = System.Windows.Forms.Appearance.Button;
            this.BtnCerrar.AutoSize = true;
            this.BtnCerrar.FlatAppearance.BorderSize = 0;
            this.BtnCerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnCerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.BtnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCerrar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnCerrar.Location = new System.Drawing.Point(543, 0);
            this.BtnCerrar.Name = "BtnCerrar";
            this.BtnCerrar.Size = new System.Drawing.Size(113, 26);
            this.BtnCerrar.TabIndex = 4;
            this.BtnCerrar.TabStop = true;
            this.BtnCerrar.Text = "Cerrar Sesion";
            this.BtnCerrar.UseVisualStyleBackColor = true;
            this.BtnCerrar.CheckedChanged += new System.EventHandler(this.BtnCerrar_CheckedChanged);
            // 
            // BtnLaboratorio
            // 
            this.BtnLaboratorio.Appearance = System.Windows.Forms.Appearance.Button;
            this.BtnLaboratorio.AutoSize = true;
            this.BtnLaboratorio.FlatAppearance.BorderSize = 0;
            this.BtnLaboratorio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnLaboratorio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.BtnLaboratorio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnLaboratorio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLaboratorio.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnLaboratorio.Location = new System.Drawing.Point(315, 0);
            this.BtnLaboratorio.Name = "BtnLaboratorio";
            this.BtnLaboratorio.Size = new System.Drawing.Size(159, 26);
            this.BtnLaboratorio.TabIndex = 3;
            this.BtnLaboratorio.TabStop = true;
            this.BtnLaboratorio.Text = "Solicitar Laboratorio";
            this.BtnLaboratorio.UseVisualStyleBackColor = true;
            this.BtnLaboratorio.CheckedChanged += new System.EventHandler(this.BtnLaboratorio_CheckedChanged);
            // 
            // BtnAdministracion
            // 
            this.BtnAdministracion.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.BtnAdministracion.Appearance = System.Windows.Forms.Appearance.Button;
            this.BtnAdministracion.AutoSize = true;
            this.BtnAdministracion.Checked = true;
            this.BtnAdministracion.FlatAppearance.BorderSize = 0;
            this.BtnAdministracion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnAdministracion.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.BtnAdministracion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAdministracion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAdministracion.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnAdministracion.Location = new System.Drawing.Point(0, 0);
            this.BtnAdministracion.Name = "BtnAdministracion";
            this.BtnAdministracion.Size = new System.Drawing.Size(120, 26);
            this.BtnAdministracion.TabIndex = 0;
            this.BtnAdministracion.TabStop = true;
            this.BtnAdministracion.Text = "Administracion";
            this.BtnAdministracion.UseVisualStyleBackColor = true;
            // 
            // BtnMantenimiento
            // 
            this.BtnMantenimiento.Appearance = System.Windows.Forms.Appearance.Button;
            this.BtnMantenimiento.AutoSize = true;
            this.BtnMantenimiento.FlatAppearance.BorderSize = 0;
            this.BtnMantenimiento.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnMantenimiento.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.BtnMantenimiento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMantenimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMantenimiento.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnMantenimiento.Location = new System.Drawing.Point(200, 0);
            this.BtnMantenimiento.Name = "BtnMantenimiento";
            this.BtnMantenimiento.Size = new System.Drawing.Size(118, 26);
            this.BtnMantenimiento.TabIndex = 2;
            this.BtnMantenimiento.TabStop = true;
            this.BtnMantenimiento.Text = "Mantenimiento";
            this.BtnMantenimiento.UseVisualStyleBackColor = true;
            this.BtnMantenimiento.CheckedChanged += new System.EventHandler(this.BtnMantenimiento_CheckedChanged);
            // 
            // BtnConsultas
            // 
            this.BtnConsultas.Appearance = System.Windows.Forms.Appearance.Button;
            this.BtnConsultas.AutoSize = true;
            this.BtnConsultas.FlatAppearance.BorderSize = 0;
            this.BtnConsultas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnConsultas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.BtnConsultas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnConsultas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnConsultas.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnConsultas.Location = new System.Drawing.Point(117, 0);
            this.BtnConsultas.Name = "BtnConsultas";
            this.BtnConsultas.Size = new System.Drawing.Size(86, 26);
            this.BtnConsultas.TabIndex = 1;
            this.BtnConsultas.TabStop = true;
            this.BtnConsultas.Text = "Consultas";
            this.BtnConsultas.UseVisualStyleBackColor = true;
            this.BtnConsultas.CheckedChanged += new System.EventHandler(this.BtnConsultas_CheckedChanged);
            // 
            // FrMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1149, 449);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.TabMenu);
            this.Name = "FrMenu";
            this.Text = "Menu";
            this.TabMenu.ResumeLayout(false);
            this.TabAdministracion.ResumeLayout(false);
            this.TabConsultas.ResumeLayout(false);
            this.TabMantenimiento.ResumeLayout(false);
            this.TabLaboratorio.ResumeLayout(false);
            this.TabLaboratorio.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl TabMenu;
        private System.Windows.Forms.TabPage TabAdministracion;
        private System.Windows.Forms.TabPage TabConsultas;
        private System.Windows.Forms.TabPage TabMantenimiento;
        private System.Windows.Forms.TabPage TabLaboratorio;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton BtnCerrar;
        private System.Windows.Forms.RadioButton BtnLaboratorio;
        private System.Windows.Forms.RadioButton BtnMantenimiento;
        private System.Windows.Forms.RadioButton BtnConsultas;
        private System.Windows.Forms.RadioButton BtnAdministracion;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
    }
}