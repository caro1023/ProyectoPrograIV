﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Plataforma
{
    public class Usuario
    {
        public static int CrearUsuario(string Usuario, string Contraseña) { 
        int resultado = 0;
        //SqlConnection conexion = conexion ;
        SqlCommand comando = new SqlCommand(string.Format(""));
        
        return resultado;
        }
    }
}
