﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace BD
{
    public class Conexion
    {
        SqlConnection ObjConexion = new SqlConnection(@"Data Source=DESKTOP-1BTE8KJ;Initial Catalog=ProyectoFinal;Integrated Security=SSPI");
        SqlCommand Comando;
        SqlDataReader dr;



        public void AbrirConexion()
        {
            try
            {
                ObjConexion.Open();
                //MessageBox.Show("Conectado");
            }
            catch(Exception e)
            {
                //MessageBox.Show("No se conecto con la base de datos" +ex.ToString());
            }

        }

        public void CerrarConexion()
        {
            try
            {
                ObjConexion.Close();
            }
            catch (Exception e)
            {
                //MessageBox.Show("No se cerró la conexion con la base de datos" +ex.ToString());
            }
        }
    }
}
