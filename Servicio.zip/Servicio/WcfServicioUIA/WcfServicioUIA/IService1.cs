﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using CapaBD; //Despues de haber agregado la referencia a WcfServicioUIA agregan este using
              //para poder utilizar la funcionalidad de este dll

namespace WcfServicioUIA
{
    
    [ServiceContract]   
    public interface IService1
    {

        [OperationContract]
        [WebInvoke(Method="POST",ResponseFormat= WebMessageFormat.Json,RequestFormat=WebMessageFormat.Json)]
        string ObtenerSaludoEstudiante();

        
        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle=WebMessageBodyStyle.WrappedRequest, ResponseFormat=WebMessageFormat.Json, RequestFormat = WebMessageFormat.Json)]
        
        string ObtenerSaludoEstudianteParametro(string nombre);


        //Noten que yo estoy retornando un listado de objetos estudiantes, la clase
        //estudiante fue la que cree en la CapaBD pero al haber referenciado ese proyecto
        //al proyecto WCF en este punto lo puedo ver y lo puedo utilizar
        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, ResponseFormat = WebMessageFormat.Json, RequestFormat = WebMessageFormat.Json)]
        List<Estudiante> ConsultarEstudiantesUIA();


        [OperationContract]
        [WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.Bare, ResponseFormat = WebMessageFormat.Json, RequestFormat = WebMessageFormat.Json)]
        Estudiante RetornarEstudiante(Estudiante p);

        

    }

    //[DataContract]
    //public class cEstudiante
    //{
    //    [DataMember]
    //    public string cNombreEstudiante { get; set; }
    //    [DataMember]
    //    public string cApellido1Estudiante { get; set; }
    //    [DataMember]
    //    public string cApellido2Estudiante { get; set; }
    //    [DataMember]
    //    public string cNacionalidadEstudiante { get; set; }
    //}

    


    
   
}
