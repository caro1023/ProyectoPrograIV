﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;



namespace CapaBD
{

  
    public class Estudiante
    {
      
       public string NombreEstudiante { get; set; }    
       public string Apellido1Estudiante { get; set; }    
       public string Apellido2Estudiante { get; set; }   
       public string NacionalidadEstudiante { get; set; }
    }
}
