﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;  //Recuerden hacer referencia a esta libreria
using System.Security.Cryptography;

namespace CapaBD
{
    
    //ESTA CLASE LA ESTOY CREANDO PARA SIMULAR LA CLASE QUE VA A TENER TOOOODO LO RELACIONADO
    //CON LA BASE DE DATOS SQLCOMMAND, SQLCONECTION, ETC.
    //SIN EMBARGO AQUI YO VOY HACER LA SIMULACION, USTEDE SI DEBEN IMPLEMENTAR TODO PARA 
    //PEGARSE A LA BASE DE DATOS
    //Recuerden que este proyecto (CapaBD) cuando se compila se va a crear un archivo .dll este es el
    //deben referenciar al proyecto WCF (WcfServicioUIA) pero primero compilan CapaBD y luego 
    //referencian.
    public class GestorBD
    {

        //Recuerden declarar (no inicializar) esta variables como globales
        SqlConnection ObjetoConexion;
        SqlCommand ObjetoComando;
        SqlDataAdapter ObjetoAdaptador;
        string CadenaConexion = @"Data Source=DESKTOP-GOAJUPT\MSSQL;Initial Catalog=ProyectoFinal;Integrated Security=True";

        private void Conexion()
        {
            ObjetoConexion = new SqlConnection();
            ObjetoConexion.ConnectionString = CadenaConexion;
            ObjetoConexion.Open();
        }

        public string ToSHA256(string value)
        {
            SHA256 sha256 = SHA256.Create();

            byte[] hashData = sha256.ComputeHash(Encoding.Default.GetBytes(value));
            StringBuilder returnValue = new StringBuilder();

            for (int i = 0; i < hashData.Length; i++)
            {
                returnValue.Append(hashData[i].ToString());
            }

            return returnValue.ToString();
        }

        public void Insertar_Usuario()
        {
          
                Conexion();
                if (ObjetoConexion.State != ConnectionState.Open)
                {
                    return;
                }
                ObjetoComando = new SqlCommand("Insertar_Usuario", ObjetoConexion);
                ObjetoComando.CommandType = CommandType.StoredProcedure;
                ObjetoComando.Connection = ObjetoConexion;
                ObjetoComando.CommandTimeout = 0;
                ObjetoComando.ExecuteNonQuery();
                ObjetoAdaptador = new SqlDataAdapter();
                ObjetoAdaptador.SelectCommand = ObjetoComando;

                //Hay que ver como se le pasan los parametros, ya que no hay forms
                ObjetoComando.Parameters.AddWithValue("@Id_Log", Id_Log.Text);
                ObjetoComando.Parameters.AddWithValue("@Usuario", Usuario.Text);
                ObjetoComando.Parameters.AddWithValue("@Contrasena", ToSHA256(Contrasena.Text));
                ObjetoComando.Parameters.AddWithValue("@Nombre", Nombre.Text);
                ObjetoComando.Parameters.AddWithValue("@TipoUsuario", TipoUsuario.Text);

                ObjetoComando.ExecuteNonQuery();
                         
        }

        public void Modificar_Usuario()
        {

            Conexion();
            if (ObjetoConexion.State != ConnectionState.Open)
            {
                return;
            }
            ObjetoComando = new SqlCommand("Modificar_Usuario", ObjetoConexion);
            ObjetoComando.CommandType = CommandType.StoredProcedure;
            ObjetoComando.Connection = ObjetoConexion;
            ObjetoComando.CommandTimeout = 0;
            ObjetoComando.ExecuteNonQuery();
            ObjetoAdaptador = new SqlDataAdapter();
            ObjetoAdaptador.SelectCommand = ObjetoComando;

            ObjetoComando.Parameters.AddWithValue("@Id_Log", Id_Log.Text);
            ObjetoComando.Parameters.AddWithValue("@Usuario", Usuario.Text);
            ObjetoComando.Parameters.AddWithValue("@Contrasena", ToSHA256(Contrasena.Text));
            ObjetoComando.Parameters.AddWithValue("@Nombre", Nombre.Text);
            ObjetoComando.Parameters.AddWithValue("@TipoUsuario", TipoUsuario.Text);

            ObjetoComando.ExecuteNonQuery();

        }

        public void Eliminar_Usuario()
        {

            Conexion();
            if (ObjetoConexion.State != ConnectionState.Open)
            {
                return;
            }
            ObjetoComando = new SqlCommand("Eliminar_Usuario", ObjetoConexion);
            ObjetoComando.CommandType = CommandType.StoredProcedure;
            ObjetoComando.Connection = ObjetoConexion;
            ObjetoComando.CommandTimeout = 0;
            ObjetoComando.ExecuteNonQuery();
            ObjetoAdaptador = new SqlDataAdapter();
            ObjetoAdaptador.SelectCommand = ObjetoComando;

            ObjetoComando.Parameters.AddWithValue("@Id_Log", Id_Log.Text);
          

            ObjetoComando.ExecuteNonQuery();

        }

        public void Consultar_Usuario()
        {

            Conexion();
            if (ObjetoConexion.State != ConnectionState.Open)
            {
                return;
            }
            ObjetoComando = new SqlCommand("Consultar_Usuario", ObjetoConexion);
            ObjetoComando.CommandType = CommandType.StoredProcedure;
            ObjetoComando.Connection = ObjetoConexion;
            ObjetoComando.CommandTimeout = 0;
            ObjetoComando.ExecuteNonQuery();
            ObjetoAdaptador = new SqlDataAdapter();
            ObjetoAdaptador.SelectCommand = ObjetoComando;

            ObjetoComando.Parameters.AddWithValue("@Id_Log", Id_Log.Text);


            ObjetoComando.ExecuteNonQuery();

        }

        public void InicioSesion()
        {
            Conexion();
            if (ObjetoConexion.State != ConnectionState.Open)
            {
                return;
            }
            ObjetoComando = new SqlCommand("Select Contrasena from Usuarios where Usuario ='" + ToSHA256(Usuario.Text) + "' ", ObjetoConexion);
            ObjetoComando.CommandType = CommandType.Text;
            ObjetoComando.Connection = ObjetoConexion;
            ObjetoComando.CommandTimeout = 0;
            ObjetoComando.ExecuteNonQuery();
            ObjetoAdaptador = new SqlDataAdapter();
            ObjetoAdaptador.SelectCommand = ObjetoComando;

          
            if (Contrasena == ToSHA256(Contrasena.Text))
            {
                //En esta parte hay que definir a donde se va a redirigir cuando entra y como se va a llamar la URL desde aqui

                //Session["New"] = Usuario.Text;
                //Response.Write("Password is correct");
                //Response.Redirect("Index.aspx");
            }
            else
            {
               // Response.Write("Password is not correct");
            }
       


else
{
    //Response.Write("Username is not correct");
}
            
        


        public List<Estudiante> ConsultarEstudiantes()
        {

            List<Estudiante> ListadoEstudiantes = new List<Estudiante>();
            
            //Aqui ustedes deben incializar ObjetoConexion y ObjetoComando
            //Establecer la respectiva configuracion para ambos para poder ir 
            //a la base de datos y realizar un Select sobre la tabla Estudiantes
            //Esa parte la hacen ustedes, yo no lo hare, yo solo creare dos estudiantes
            //lo cargare en una lista que será la que voy a retornar, esto solo para efectos de 
            //que tengan un ejemplo con WCF y cliente HTML

            //Creo el primer estudiante
            Estudiante ObjetoEstudiante = new Estudiante();
            ObjetoEstudiante.NombreEstudiante = "Carlos";
            ObjetoEstudiante.Apellido1Estudiante = "Gonzalez";
            ObjetoEstudiante.Apellido2Estudiante = "Romero";
            ObjetoEstudiante.NacionalidadEstudiante = "Costarricense";            
            ListadoEstudiantes.Add(ObjetoEstudiante); //Lo agrego a la lista

            //Creo el segundo estudiante
            ObjetoEstudiante = new Estudiante(); //Solo inicializo nuevamente la variable ObjetoEstudiante
            ObjetoEstudiante.NombreEstudiante = "Rosibel";
            ObjetoEstudiante.Apellido1Estudiante = "Cordoba";
            ObjetoEstudiante.Apellido2Estudiante = "Castro";
            ObjetoEstudiante.NacionalidadEstudiante = "Argentina";
            ListadoEstudiantes.Add(ObjetoEstudiante); //Lo agrego a la lista

            //Retorno la lista
            return ListadoEstudiantes;

        }

    }
}
