﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaBD
{
    class Laboratorios
    {

        public int Numero_lab { get; set; }
        public string Computadoras { get; set; }
        public string Configuracion { get; set; }
        public string SoftwareInstalado { get; set; }
        public string ServidoresInstalado { get; set; }
        public int Piso { get; set; }
        public Boolean Aire_Acondicionado { get; set; }
        public Boolean VideoBeam { get; set; }

    }
}
