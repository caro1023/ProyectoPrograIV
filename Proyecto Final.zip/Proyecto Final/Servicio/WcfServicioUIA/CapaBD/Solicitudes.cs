﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaBD
{
    class Solicitudes
    {

        public int Id_Solicitud { get; set; }
        public int Id_Lab { get; set; }
        public int Id_Usuario { get; set; }
        public string Nombre { get; set; }
        public int Codigo_Curso { get; set; }
        public int Confirmado { get; set; }
        public DateTime Fecha_Solicitud { get; set; }
        public DateTime Fecha_Ocupado { get; set; }
    }
}
