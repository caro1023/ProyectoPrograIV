﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient; 
using System.Security.Cryptography;

namespace CapaBD
{
    

    public class GestorBD
    {

        SqlConnection ObjetoConexion;
        SqlCommand ObjetoComando;
        SqlDataAdapter ObjetoAdaptador;
        string CadenaConexion = @"Data Source=DESKTOP-GOAJUPT\MSSQL;Initial Catalog=ProyectoFinal;Integrated Security=True";

        private void Conexion()
        {
            ObjetoConexion = new SqlConnection();
            ObjetoConexion.ConnectionString = CadenaConexion;
            ObjetoConexion.Open();
        }

        public string ToSHA256(string value)
        {
            SHA256 sha256 = SHA256.Create();

            byte[] hashData = sha256.ComputeHash(Encoding.Default.GetBytes(value));
            StringBuilder returnValue = new StringBuilder();

            for (int i = 0; i < hashData.Length; i++)
            {
                returnValue.Append(hashData[i].ToString());
            }

            return returnValue.ToString();
        }

        public void Insertar_Usuario()
        {
          
                Conexion();
                if (ObjetoConexion.State != ConnectionState.Open)
                {
                    return;
                }
                ObjetoComando = new SqlCommand("Insertar_Usuario", ObjetoConexion);
                ObjetoComando.CommandType = CommandType.StoredProcedure;
                ObjetoComando.Connection = ObjetoConexion;
                ObjetoComando.CommandTimeout = 0;
                ObjetoComando.ExecuteNonQuery();
                ObjetoAdaptador = new SqlDataAdapter();
                ObjetoAdaptador.SelectCommand = ObjetoComando;

                ObjetoComando.Parameters.AddWithValue("@Id_Log", Id_Log.Text);
                ObjetoComando.Parameters.AddWithValue("@Usuario", Usuario.Text);
                ObjetoComando.Parameters.AddWithValue("@Contrasena", ToSHA256(Contrasena.Text));
                ObjetoComando.Parameters.AddWithValue("@Nombre", Nombre.Text);
                ObjetoComando.Parameters.AddWithValue("@Rol", Rol.Text);

                ObjetoComando.ExecuteNonQuery();
                         
        }

        public void Modificar_Usuario()
        {

            Conexion();
            if (ObjetoConexion.State != ConnectionState.Open)
            {
                return;
            }
            ObjetoComando = new SqlCommand("Modificar_Usuario", ObjetoConexion);
            ObjetoComando.CommandType = CommandType.StoredProcedure;
            ObjetoComando.Connection = ObjetoConexion;
            ObjetoComando.CommandTimeout = 0;
            ObjetoComando.ExecuteNonQuery();
            ObjetoAdaptador = new SqlDataAdapter();
            ObjetoAdaptador.SelectCommand = ObjetoComando;

            ObjetoComando.Parameters.AddWithValue("@Id_Log", Id_Log.Text);
            ObjetoComando.Parameters.AddWithValue("@Usuario", Usuario.Text);
            ObjetoComando.Parameters.AddWithValue("@Contrasena", ToSHA256(Contrasena.Text));
            ObjetoComando.Parameters.AddWithValue("@Nombre", Nombre.Text);
            ObjetoComando.Parameters.AddWithValue("@Rol", Rol.Text);

            ObjetoComando.ExecuteNonQuery();

        }

        public void Eliminar_Usuario()
        {

            Conexion();
            if (ObjetoConexion.State != ConnectionState.Open)
            {
                return;
            }
            ObjetoComando = new SqlCommand("Eliminar_Usuario", ObjetoConexion);
            ObjetoComando.CommandType = CommandType.StoredProcedure;
            ObjetoComando.Connection = ObjetoConexion;
            ObjetoComando.CommandTimeout = 0;
            ObjetoComando.ExecuteNonQuery();
            ObjetoAdaptador = new SqlDataAdapter();
            ObjetoAdaptador.SelectCommand = ObjetoComando;

            ObjetoComando.Parameters.AddWithValue("@Usuario", Usuario.Text);
          

            ObjetoComando.ExecuteNonQuery();

        }

        public void Consultar_Usuario()
        {

            Conexion();
            if (ObjetoConexion.State != ConnectionState.Open)
            {
                return;
            }
            ObjetoComando = new SqlCommand("Consultar_Usuario", ObjetoConexion);
            ObjetoComando.CommandType = CommandType.StoredProcedure;
            ObjetoComando.Connection = ObjetoConexion;
            ObjetoComando.CommandTimeout = 0;
            ObjetoComando.ExecuteNonQuery();
            ObjetoAdaptador = new SqlDataAdapter();
            ObjetoAdaptador.SelectCommand = ObjetoComando;

            ObjetoComando.Parameters.AddWithValue("@Usuario", Usuario.Text);


            ObjetoComando.ExecuteNonQuery();

        }

        public void InicioSesion()
        {
            Conexion();
            if (ObjetoConexion.State != ConnectionState.Open)
            {
                return;
            }
            ObjetoComando = new SqlCommand("Select Contrasena from Usuarios where Usuario ='" + ToSHA256(Usuario.Text) + "' ", ObjetoConexion);
            ObjetoComando.CommandType = CommandType.Text;
            ObjetoComando.Connection = ObjetoConexion;
            ObjetoComando.CommandTimeout = 0;
            ObjetoComando.ExecuteNonQuery();
            ObjetoAdaptador = new SqlDataAdapter();
            ObjetoAdaptador.SelectCommand = ObjetoComando;


            if (Contrasena == ToSHA256(Contrasena.Text))
            {
                //En esta parte hay que definir a donde se va a redirigir cuando entra y como se va a llamar la URL desde aqui

                //Session["New"] = Usuario.Text;
                //Response.Write("Password is correct");
                //Response.Redirect("Index.aspx");
            }
            else
            {
                // Response.Write("Password is not correct");
            }


        }

        /*else
        {
            //Response.Write("Username is not correct");
        }*/



        public void Insertar_Laboratorio()
        {

            Conexion();
            if (ObjetoConexion.State != ConnectionState.Open)
            {
                return;
            }
            ObjetoComando = new SqlCommand("Insertar_Laboratorio", ObjetoConexion);
            ObjetoComando.CommandType = CommandType.StoredProcedure;
            ObjetoComando.Connection = ObjetoConexion;
            ObjetoComando.CommandTimeout = 0;
            ObjetoComando.ExecuteNonQuery();
            ObjetoAdaptador = new SqlDataAdapter();
            ObjetoAdaptador.SelectCommand = ObjetoComando;

 
            ObjetoComando.Parameters.AddWithValue("@Numero_lab", Numero_lab.Text);
            ObjetoComando.Parameters.AddWithValue("@Computadoras", Computadoras.Text);
            ObjetoComando.Parameters.AddWithValue("@Configuracion", Configuracion(Contrasena.Text));
            ObjetoComando.Parameters.AddWithValue("@SoftwareInstalado", SoftwareInstalado.Text);
            ObjetoComando.Parameters.AddWithValue("@Piso", Piso.Text);
            ObjetoComando.Parameters.AddWithValue("@Aire_Acondicionado", Aire_Acondicionado.Text);
            ObjetoComando.Parameters.AddWithValue("@VideoBeam", VideoBeam.Text);

            ObjetoComando.ExecuteNonQuery();

        }

        public void Modificar_Laboratorio()
        {

            Conexion();
            if (ObjetoConexion.State != ConnectionState.Open)
            {
                return;
            }
            ObjetoComando = new SqlCommand("Modificar_Laboratorio", ObjetoConexion);
            ObjetoComando.CommandType = CommandType.StoredProcedure;
            ObjetoComando.Connection = ObjetoConexion;
            ObjetoComando.CommandTimeout = 0;
            ObjetoComando.ExecuteNonQuery();
            ObjetoAdaptador = new SqlDataAdapter();
            ObjetoAdaptador.SelectCommand = ObjetoComando;

            ObjetoComando.Parameters.AddWithValue("@Numero_lab", Numero_lab.Text);
            ObjetoComando.Parameters.AddWithValue("@Computadoras", Computadoras.Text);
            ObjetoComando.Parameters.AddWithValue("@Configuracion", Configuracion(Contrasena.Text));
            ObjetoComando.Parameters.AddWithValue("@SoftwareInstalado", SoftwareInstalado.Text);
            ObjetoComando.Parameters.AddWithValue("@Piso", Piso.Text);
            ObjetoComando.Parameters.AddWithValue("@Aire_Acondicionado", Aire_Acondicionado.Text);
            ObjetoComando.Parameters.AddWithValue("@VideoBeam", VideoBeam.Text);

            ObjetoComando.ExecuteNonQuery();

        }

        public void Eliminar_Laboratorio()
        {

            Conexion();
            if (ObjetoConexion.State != ConnectionState.Open)
            {
                return;
            }
            ObjetoComando = new SqlCommand("Eliminar_Laboratorio", ObjetoConexion);
            ObjetoComando.CommandType = CommandType.StoredProcedure;
            ObjetoComando.Connection = ObjetoConexion;
            ObjetoComando.CommandTimeout = 0;
            ObjetoComando.ExecuteNonQuery();
            ObjetoAdaptador = new SqlDataAdapter();
            ObjetoAdaptador.SelectCommand = ObjetoComando;

            ObjetoComando.Parameters.AddWithValue("@Numero_lab", Numero_lab.Text);


            ObjetoComando.ExecuteNonQuery();

        }

        public void Consultar_Laboratorio()
        {

            Conexion();
            if (ObjetoConexion.State != ConnectionState.Open)
            {
                return;
            }
            ObjetoComando = new SqlCommand("Consultar_Laboratorio", ObjetoConexion);
            ObjetoComando.CommandType = CommandType.StoredProcedure;
            ObjetoComando.Connection = ObjetoConexion;
            ObjetoComando.CommandTimeout = 0;
            ObjetoComando.ExecuteNonQuery();
            ObjetoAdaptador = new SqlDataAdapter();
            ObjetoAdaptador.SelectCommand = ObjetoComando;

            ObjetoComando.Parameters.AddWithValue("@Numero_lab", Numero_lab.Text);


            ObjetoComando.ExecuteNonQuery();

        }

        public void Consultar_Solicitudes()
        {

            Conexion();
            if (ObjetoConexion.State != ConnectionState.Open)
            {
                return;
            }
            ObjetoComando = new SqlCommand("Consultar_Solicitudes", ObjetoConexion);
            ObjetoComando.CommandType = CommandType.StoredProcedure;
            ObjetoComando.Connection = ObjetoConexion;
            ObjetoComando.CommandTimeout = 0;
            ObjetoComando.ExecuteNonQuery();
            ObjetoAdaptador = new SqlDataAdapter();
            ObjetoAdaptador.SelectCommand = ObjetoComando;

            ObjetoComando.Parameters.AddWithValue("@fechaIni", Fecha_Ocupado.Text);
            ObjetoComando.Parameters.AddWithValue("@fechaFina", Fecha_Ocupado.Text);
            ObjetoComando.Parameters.AddWithValue("@Usuario", Id_Usuario.Text);
            ObjetoComando.Parameters.AddWithValue("@Lab", Id_Lab.Text);


            ObjetoComando.ExecuteNonQuery();

        }




    }
}
