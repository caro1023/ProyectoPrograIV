﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using CapaBD; 

namespace WcfServicioUIA
{    

        [ServiceContract]
        public interface IService1
        {

            [OperationContract]
            [FaultContract(typeof(ExceptionMessage))]
            void voidInicioSesion();

            [OperationContract]
            [FaultContract(typeof(ExceptionMessage))]
            void Consultar_Usuario();

            [OperationContract]
            [FaultContract(typeof(ExceptionMessage))]
            void Eliminar_Usuario();

            [OperationContract]
            [FaultContract(typeof(ExceptionMessage))]
            void Modificar_Usuario();

            [OperationContract]
            [FaultContract(typeof(ExceptionMessage))]
            void Insertar_Usuario();

            [OperationContract]
            [FaultContract(typeof(ExceptionMessage))]
            void Insertar_Laboratorio();

            [OperationContract]
            [FaultContract(typeof(ExceptionMessage))]
            void Modificar_Laboratorio();

            [OperationContract]
            [FaultContract(typeof(ExceptionMessage))]
            void Eliminar_Laboratorio();

            [OperationContract]
            [FaultContract(typeof(ExceptionMessage))]
            void Consultar_Laboratorio();

    }


    [DataContract]
    public class Usuarios
    {
        [DataMember]
        public int Id_Log;
        [DataMember]
        public string Usuario;
        [DataMember]
        public string Contraseña;
        [DataMember]
        public string Nombre;
        [DataMember]
        public int Rol;
        [DataMember]
        public int Id_Lab;
        [DataMember]
        public int Numero_lab;
        [DataMember]
        public string Computadoras;
        [DataMember]
        public string Configuacion;
        [DataMember]
        public string SoftwareInstalado;
        [DataMember]
        public string ServidoresInstalado;
        [DataMember]
        public int Piso;
        [DataMember]
        public Boolean Aire_Acondicionado;
        [DataMember]
        public Boolean VideoBeam;


    }

    [DataContract]
        public class ExceptionMessage
        {
            private string infoExceptionMessage;
            public ExceptionMessage(string Message)
            {
                this.infoExceptionMessage = Message;
            }
            [DataMember]
            public string errorMessageOfAction
            {
                get { return this.infoExceptionMessage; }
                set { this.infoExceptionMessage = value; }
            }
        }





    }



    


    
   

